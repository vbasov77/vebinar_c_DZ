﻿Console.WriteLine("Введите трехзначное число.");
string number = Console.ReadLine();
Console.WriteLine("{0}->{1}", number, number[1]);
